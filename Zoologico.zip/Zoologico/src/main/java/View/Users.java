/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

/**
 *
 * @author jhon.argaez
 */
public class Users{
    
    int document;
    short age;

    public Users() {
    }

    public Users(int document, short age) {
        this.document = document;
        this.age = age;
    }

    public int getDocument() {
        return document;
    }

    public void setDocument(int document) {
        this.document = document;
    }

    public short getAge() {
        return age;
    }

    public void setAge(short age) {
        this.age = age;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Users{");
        sb.append("document=").append(document);
        sb.append(", age=").append(age);
        sb.append('}');
        return sb.toString();
    }
    
    
}
