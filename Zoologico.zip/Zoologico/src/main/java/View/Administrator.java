/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

/**
 *
 * @author Asus
 */
public class Administrator {
    
    String day;

    public Administrator() {
    }

    public Administrator(String day) {
        this.day = day;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public static void sell(){
        
    }
    
    public static void consult(){
        
    }
    
    public static void delete(){
        
    }
    
    public static void edit(){
        
    }
    
    
    
}
