/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

/**
 *
 * @author jhon.argaez
 */
public class Animals {
    String name;
    short ide;
    int specie;
    String tipe;
    String habitat;
    Float weight;

    public Animals() {
    }

    public Animals(String name, short ide, int specie, String tipe, String habitat, Float weight) {
        this.name = name;
        this.ide = ide;
        this.specie = specie;
        this.tipe = tipe;
        this.habitat = habitat;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public short getIde() {
        return ide;
    }

    public void setIde(short ide) {
        this.ide = ide;
    }

    public int getSpecie() {
        return specie;
    }

    public void setSpecie(int specie) {
        this.specie = specie;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }
    
    
    
}
